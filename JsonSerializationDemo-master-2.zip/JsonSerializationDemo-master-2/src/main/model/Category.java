package model;

// Represents categories of thingies
public enum Category {
    WOODWORK, METALWORK, STITCHING, KNITTING;
}
